scp index.html gsinclair@rubyforge.org:/var/www/gforge-projects/vim-ruby/
